# Brutal Company
A hardcore mod for lethal company


# Features
Increased difficulty

Random moon events

New mechanics

Syncing to clients who dont have the mod


# Notes
ONLY THE HOST SHOULD HAVE THE MOD RUNNING!

I intended for only the host to run the mod, so if you are going to be joining a friend, dont install the mod! have the host install it instead!

# Releases

# Version 1.0.0
- Release

# Version 1.1.0
- 3 New events have been added

- Heat gained per visit reduced from 25% to 15%

# Version 1.1.1
- Fix for one event not being turned off right away when leaving the moon

- Reworked one of the events to now have its effect last the entire duration that you stay on a moon rather than being a set duration

# Version 1.1.2
- General bug fixes

# Version 1.2.0
- Added 1 new event

- Change to events that spawn hazards to make them despawn once the next event starts

# Version 1.2.1
- Fix for the new event being unable to be triggered

# Version 1.2.2
- General bug fixes

# Version 1.2.3
- General bug fixes

# Version 1.2.4
- Fixed README formatting

